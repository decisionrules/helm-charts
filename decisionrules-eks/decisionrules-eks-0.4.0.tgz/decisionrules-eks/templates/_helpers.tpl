{{/*
Render one env entry for a sensitive variable.

When secrets.existingSecret is set, the variable is read from that Secret
(key name in the Secret must match the env var name) and the inline value
is ignored. Otherwise the inline value from values.yaml is used directly.

Usage:
  {{- include "decisionrules.secretEnv" (dict "root" $ "key" "MONGO_DB_URI" "value" .Values.env.server.MONGO_DB_URI) | nindent 8 }}
*/}}
{{- define "decisionrules.secretEnv" -}}
- name: {{ .key }}
{{- if .root.Values.secrets.existingSecret }}
  valueFrom:
    secretKeyRef:
      name: {{ .root.Values.secrets.existingSecret }}
      key: {{ .key }}
{{- else }}
  value: {{ .value | quote }}
{{- end }}
{{- end }}

{{/*
Server CPU/memory and autoscaling range for the selected rule solver (.Values.solver).
  aero (default): Aero (V2) solver or mixed V1/V2 traffic, fewer and larger replicas.
  gaia: classic Gaia (V1) solver.
resources.server and autoscalingServer.minReplicas/maxReplicas override the profile when set.
*/}}
{{- define "decisionrules.solverProfile" -}}
{{- $solver := .Values.solver | default "aero" -}}
{{- if eq $solver "aero" -}}
resources:
  requests:
    cpu: 4000m
    memory: 8Gi
  limits:
    cpu: 4000m
    memory: 8Gi
minReplicas: 2
maxReplicas: 5
{{- else if eq $solver "gaia" -}}
resources:
  requests:
    cpu: 1000m
    memory: 1Gi
  limits:
    cpu: 2000m
    memory: 2Gi
minReplicas: 2
maxReplicas: 10
{{- else -}}
{{- fail (printf "solver must be \"aero\" or \"gaia\", got %q" $solver) -}}
{{- end -}}
{{- end }}
